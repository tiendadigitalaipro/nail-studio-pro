@echo off
chcp 65001 >nul 2>&1
title SynthTrade Pro - Instalador Automatico
color 0A

echo ╔══════════════════════════════════════════════════════╗
echo ║     SYNTHTRADE PRO - INSTALADOR AUTOMATICO          ║
echo ║     Bot de Trading para Indices Sinteticos          ║
echo ╚══════════════════════════════════════════════════════╝
echo.

:: Verificar si Bun esta instalado
echo [1/6] Verificando Bun...
where bun >nul 2>&1
if %errorlevel% neq 0 (
    echo    ❌ Bun no esta instalado. Instalando...
    echo.
    powershell -Command "irm bun.sh/install.ps1 | iex"
    echo.
    echo    ✅ Bun instalado. Cerrando esta ventana...
    echo    Vuelve a abrir este archivo .bat despues.
    pause
    exit
)
echo    ✅ Bun encontrado.
echo.

:: Verificar si esta en la carpeta correcta
echo [2/6] Verificando estructura del proyecto...
if not exist "package.json" (
    echo    ❌ No se encuentra package.json
    echo    Debes colocar este archivo EN la carpeta del proyecto SynthTradePro
    echo    (la misma carpeta que contiene package.json, src, prisma, etc.)
    echo.
    pause
    exit
)
echo    ✅ Estructura correcta.
echo.

:: Crear archivo .env
echo [3/6] Creando archivo .env...
echo DATABASE_URL=file:./db/custom.db > .env
if not exist "db" mkdir db
echo    ✅ Archivo .env creado.
echo.

:: Instalar dependencias
echo [4/6] Instalando dependencias (puede tardar 1-3 minutos)...
bun install
if %errorlevel% neq 0 (
    echo    ❌ Error al instalar dependencias.
    pause
    exit
)
echo    ✅ Dependencias instaladas.
echo.

:: Generar Prisma
echo [5/6] Configurando base de datos...
bun run db:generate
if %errorlevel% neq 0 (
    echo    ❌ Error al generar Prisma.
    pause
    exit
)
echo    ✅ Prisma generado.
echo.

bun run db:push
if %errorlevel% neq 0 (
    echo    ❌ Error al crear tablas.
    pause
    exit
)
echo    ✅ Tablas creadas.
echo.

:: Compilar
echo [6/6] Verificando compilacion...
bun run build
if %errorlevel% neq 0 (
    echo    ⚠️  La compilacion tuvo warnings, pero puede funcionar igual.
    echo.
)
echo    ✅ Listo.
echo.

echo ╔══════════════════════════════════════════════════════╗
echo ║            INSTALACION COMPLETADA                   ║
echo ╚══════════════════════════════════════════════════════╝
echo.
echo    Para INICIAR el bot, ejecuta este comando:
echo.
echo       bun run dev
echo.
echo    Luego abre tu navegador en:
echo.
echo       http://localhost:3000
echo.
echo ══════════════════════════════════════════════════════
echo    Presiona cualquier tecla para iniciar el bot ahora...
echo ══════════════════════════════════════════════════════
pause >nul

echo Iniciando servidor de desarrollo...
echo Abre tu navegador en: http://localhost:3000
echo Presiona Ctrl+C para detener el servidor.
echo.
bun run dev
